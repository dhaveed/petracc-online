<?php

/**
* WPBakery Page Builder Ohio Recent Projects shortcode view
*/

include( plugin_dir_path( __FILE__ ) . 'views/recent_projects__view_default.php' );